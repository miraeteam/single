package Controll;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import Model.MemberVo;
import Model.MovieVo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ManagerInfoController implements Initializable{
	@FXML private Button btnMovieUpload;
	@FXML private Button btnBranchUpload;
	@FXML private Button btnCinemaUpload;
	@FXML private Button btnMovieDelete;
	@FXML private Button btnMovieTime;
	@FXML private Button btnTimeDelete;
	@FXML private Button btnBarChart;
	@FXML private Button btnInfoCancle;
	ObservableList<MovieVo> data = FXCollections.observableArrayList();
	ObservableList<MemberVo> data2 = FXCollections.observableArrayList();
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
		btnBarChart.setOnAction(event ->{
			try {
				Stage dialog = new Stage(StageStyle.UTILITY);
				dialog.initModality(Modality.WINDOW_MODAL);
				dialog.initOwner(btnBarChart.getScene().getWindow());
				dialog.setTitle("���� �׷���");
				Parent parent = FXMLLoader.load(getClass().getResource("/view/areachart.fxml"));
				AreaChart AreaChart = (AreaChart) parent.lookup("#areachart");
			
				AreaChart.Series seriesTor = new AreaChart.Series();
				seriesTor.setName("�丣");
				ObservableList torList = FXCollections.observableArrayList();
				for (int i = 0; i < data.size(); i++) {
					torList.add(new AreaChart.Data(data.get(i).getTitle(), Integer.parseInt(data2.get(i).getPhone1())));
				}
				seriesTor.setData(torList);
				AreaChart.getData().add(seriesTor);
				
				AreaChart.Series seriesJus = new AreaChart.Series();
				seriesJus.setName("����Ƽ������");
				ObservableList jusList = FXCollections.observableArrayList();
				for (int i = 0; i < data.size(); i++) {
					jusList.add(new AreaChart.Data(data.get(i).getTitle(), Integer.parseInt(data2.get(i).getMemberNumber())));
				}
				seriesJus.setData(jusList);
				AreaChart.getData().add(seriesJus);
				
				AreaChart.Series seriesHappy = new AreaChart.Series();
				seriesHappy.setName("���ǵ�������");
				ObservableList happyList = FXCollections.observableArrayList();
				for (int i = 0; i < data.size(); i++) {
					happyList.add(new AreaChart.Data(data.get(i).getTitle(), Integer.parseInt(data2.get(i).getMemberNumber())));
				}
				seriesHappy.setData(happyList);
				AreaChart.getData().add(seriesHappy);
				
				AreaChart.Series seriesCity = new AreaChart.Series();
				seriesCity.setName("���˵���");
				ObservableList cityList = FXCollections.observableArrayList();
				for (int i = 0; i < data.size(); i++) {
					cityList.add(new AreaChart.Data(data.get(i).getTitle(), Integer.parseInt(data2.get(i).getMemberNumber())));
				}
				seriesCity.setData(cityList);
				AreaChart.getData().add(seriesCity);
				
				AreaChart.Series seriesGgun = new AreaChart.Series();
				seriesGgun.setName("��");
				ObservableList ggunList = FXCollections.observableArrayList();
				for (int i = 0; i < data.size(); i++) {
					ggunList.add(new AreaChart.Data(data.get(i).getTitle(), Integer.parseInt(data2.get(i).getMemberNumber())));
				}
				seriesGgun.setData(ggunList);
				AreaChart.getData().add(seriesGgun);
				
				
				// ����Ʈ ����
				Button btnClose = (Button) parent.lookup("#btnClose");
				btnClose.setOnAction(e -> dialog.close());
				Scene scene = new Scene(parent);
				dialog.setScene(scene);
				dialog.show();
			} catch (IOException e) {
			}
		
		});
		btnInfoCancle.setOnAction(event ->{
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Main.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("Main");
				mainMtage.setScene(scene);
				Stage oldStage = (Stage)btnInfoCancle.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}
		});
		btnMovieTime.setOnAction(event -> {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ScreenSchedule.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("Time");
				mainMtage.setScene(scene);
				Stage oldStage = (Stage)btnMovieTime.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}
		});
		
		btnMovieDelete.setOnAction(event -> {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MovieDelete.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("MovieDelete");
				mainMtage.setScene(scene);
				Stage oldStage = (Stage)btnMovieUpload.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}
		});
		
		btnMovieUpload.setOnAction(event -> {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MovieUpload.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("Manager");
				mainMtage.setScene(scene);
				Stage oldStage = (Stage)btnMovieUpload.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}
		});
		
		btnBranchUpload.setOnAction(event -> {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Branch.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("Branch");
				mainMtage.setScene(scene);
				Stage oldStage = (Stage)btnBranchUpload.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}
		});
		
		btnCinemaUpload.setOnAction(event -> {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Cinema.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("Cinema");
				mainMtage.setScene(scene);
				Stage oldStage = (Stage)btnCinemaUpload.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}
		});
		btnTimeDelete.setOnAction(event -> {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/TimeDelete.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("TimeDelete");
				mainMtage.setScene(scene);
				Stage oldStage = (Stage)btnCinemaUpload.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}
		});
		
	}

}
