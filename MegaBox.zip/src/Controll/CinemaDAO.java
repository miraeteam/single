package Controll;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.BranchVo;
import Model.CinemaVo;
import Controll.DBUtil;


public class CinemaDAO {
	//�󿵰� db ���ε�
	public CinemaVo getCinemaUpload(CinemaVo cvo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into Cinema");
		sql.append(" values (cinema_seq.nextval, ?, ?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		CinemaVo cVo = cvo;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, cVo.getCinema());
			pstmt.setString(2, cVo.getB_cinema());
			

			int i = pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("e = / " + e);
		} catch (Exception e) {
			System.out.println("e = / " + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {

			}
		}
		return cVo;
	}
	public ArrayList<CinemaVo> getCinemaSearch(){
		ArrayList<CinemaVo> list = new ArrayList<CinemaVo>();
		StringBuffer sql = new StringBuffer();
		sql.append("select c_cinema  ");
		sql.append(" from cinema order by c_number ");
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CinemaVo cVo = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				cVo = new CinemaVo();
				cVo.setCinema(rs.getString("c_cinema"));
				
				list.add(cVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return list;
	}
	
	public CinemaVo getCinema(String cinema) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * ");
		sql.append(" from cinema where c_cinema=?  order by c_number");

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		CinemaVo cVo = new CinemaVo();
		try {
			
			con = DBUtil.getConnection();
			ps = con.prepareStatement(sql.toString());
			ps.setString(1, cinema);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				cVo = new CinemaVo(rs.getString(1), rs.getString(2), rs.getString(3));
			
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return cVo;
	}
}
