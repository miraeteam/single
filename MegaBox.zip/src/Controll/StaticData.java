package Controll;

import java.time.LocalDate;

import Model.BranchVo;
import Model.CinemaVo;
import Model.MovieVo;

public class StaticData {
	public final static int ADULT = 9000;
	public final static int TEEN = 8000;
	public final static int CHILD = 6000;
	public final static int SPECIAL = 5000;
	public static String payment;
	public static String payment2;
	public static String time;
	public static int seat;

	
	public static String cinema;
	public static LocalDate date;
	public static String movie;
	public static String eMovie;
	public static MovieVo poster;
	public static BranchVo branchVo;
	public static CinemaVo cinemaVo;
	public static MovieVo movieVo;

	public static String seatNumber;
	
	public static String adult;
	public static String teen;
	public static String child;
	public static String special;
	


	public void reset() {
		payment = null;
		time = null;
		adult = null;
		teen = null;
		child = null;
		special = null;
		
	}
	
	
}
