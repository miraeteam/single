package Controll;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Observable;
import java.util.ResourceBundle;

import Model.BranchVo;
import Model.CinemaVo;
import Model.MovieVo;
import Model.ScreenScheduleVo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class ScreenScheduleController implements Initializable {
	@FXML
	private TextField txtScreenTime;
	@FXML
	private Button btnTimeUpload;
	@FXML
	private ComboBox<String> cbTCinema;
	@FXML
	private ComboBox<String> cbTMovie;
	@FXML
	private ComboBox<String> cbTBranch;

	String movie1;
	String movie2;
	String movie3;
	String movie4;
	String movie5;
	String cinema1;
	String cinema2;
	String cinema3;
	String cinema4;
	String cinema5;
	String cinema6;
	String cinema7;
	String cinema8;
	String cinema9;
	String cinema10;
	String cinema11;
	String cinema12;
	String branch1;
	String branch2;
	String branch3;
	String branch4;
	ObservableList<ScreenScheduleVo> data = FXCollections.observableArrayList();
	ObservableList<String> timeData = FXCollections.observableArrayList();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		branchTitle();
		cbTBranch.setItems(FXCollections.observableArrayList(branch1, branch2, branch3, branch4));
		movieTitle();
		cbTMovie.setItems(FXCollections.observableArrayList(movie1, movie2, movie3, movie4, movie5));
		cinemaTitle();
		cbTCinema.setItems(FXCollections.observableArrayList(cinema1, cinema2, cinema3));

		cbTBranch.setOnAction(event -> {
			if (cbTBranch.getSelectionModel().getSelectedItem().equals("����")) {
				cbTCinema.setItems(FXCollections.observableArrayList(cinema6, cinema7, cinema8));
			} else if (cbTBranch.getSelectionModel().getSelectedItem().equals("�������")) {
				cbTCinema.setItems(FXCollections.observableArrayList(cinema9, cinema10, cinema11));
			} else if (cbTBranch.getSelectionModel().getSelectedItem().equals("��Ʈ��")) {
				cbTCinema.setItems(FXCollections.observableArrayList(cinema12, cinema1, cinema2));
			} else if (cbTBranch.getSelectionModel().getSelectedItem().equals("�ڿ���")) {
				cbTCinema.setItems(FXCollections.observableArrayList(cinema3, cinema4, cinema5));
			}
		});
		btnTimeUpload.setOnAction(event -> {
			try {
				data.removeAll(data);
				ScreenScheduleVo sVo = null;
				ScreenScheduleDAO sDao = new ScreenScheduleDAO();
				if (event.getSource().equals(btnTimeUpload)) {
					sVo = new ScreenScheduleVo(txtScreenTime.getText(), cbTBranch.getSelectionModel().getSelectedItem(),
							cbTMovie.getSelectionModel().getSelectedItem(),
							cbTCinema.getSelectionModel().getSelectedItem());
					sDao = new ScreenScheduleDAO();
					sDao.getScreenTimeUpload(sVo);
					if (sDao != null) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("��ȭ ���� �Է�");
						alert.setHeaderText(" ��ȭ�� ������ ���������� �߰��Ǿ����ϴ�.");
						alert.setContentText("���� ��ȭ������ �Է��ϼ���");

						txtScreenTime.clear();
						
						FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Main.fxml"));
						Parent mainView = (Parent) loader.load();
						Scene scene = new Scene(mainView);
						Stage mainMtage = new Stage();
						Stage oldStage = (Stage) btnTimeUpload.getScene().getWindow();
						oldStage.close();
						mainMtage.setTitle("Main");
						mainMtage.setScene(scene);
						mainMtage.show();

					}

				}
			} catch (Exception ie) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��ȭ ���� �Է�");
				alert.setHeaderText("��ȭ ������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
		});
	}

	public void movieTitle() {
		MovieDAO mDao = new MovieDAO();
		MovieVo mVo = new MovieVo();
		ArrayList<MovieVo> list;

		list = mDao.getTitleSearch();
		int rowCount = list.size();
		for (int index = 0; index < rowCount; index++) {
			mVo = list.get(index);
			switch (index) {
			case 0:
				movie1 = mVo.getTitle();
				break;
			case 1:
				movie2 = mVo.getTitle();
				break;
			case 2:
				movie3 = mVo.getTitle();
				break;
			case 3:
				movie4 = mVo.getTitle();
				break;
			case 4:
				movie5 = mVo.getTitle();
				break;
			}
		}
	}

	public void branchTitle() {
		BranchDAO bDao = new BranchDAO();
		BranchVo bVo = new BranchVo();
		ArrayList<BranchVo> list;

		list = bDao.getBranchSearch();
		int rowCount = list.size();
		for (int index = 0; index < rowCount; index++) {
			bVo = list.get(index);
			switch (index) {
			case 0:
				branch1 = bVo.getBranchName();
				break;
			case 1:
				branch2 = bVo.getBranchName();
				break;
			case 2:
				branch3 = bVo.getBranchName();
				break;
			case 3:
				branch4 = bVo.getBranchName();
				break;

			}

		}
	}

	public void cinemaTitle() {
		CinemaDAO cDao = new CinemaDAO();
		CinemaVo cVo = new CinemaVo();
		String combo = cbTBranch.getSelectionModel().getSelectedItem();
		ArrayList<CinemaVo> list;
		list = cDao.getCinemaSearch();
		int rowCount = list.size();

		for (int index = 0; index < rowCount; index++) {
			cVo = list.get(index);
			switch (index) {
			case 0:
				cinema1 = cVo.getCinema();
				break;
			case 1:
				cinema2 = cVo.getCinema();
				break;
			case 2:
				cinema3 = cVo.getCinema();
				break;
			case 3:
				cinema4 = cVo.getCinema();
				break;
			case 4:
				cinema5 = cVo.getCinema();
				break;
			case 5:
				cinema6 = cVo.getCinema();
				break;
			case 6:
				cinema7 = cVo.getCinema();
				break;
			case 7:
				cinema8 = cVo.getCinema();
				break;
			case 8:
				cinema9 = cVo.getCinema();
				break;
			case 9:
				cinema10 = cVo.getCinema();
				break;
			case 10:
				cinema11 = cVo.getCinema();
				break;
			case 11:
				cinema12 = cVo.getCinema();
				break;
			}

		}
	}

}
