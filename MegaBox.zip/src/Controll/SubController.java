package Controll;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.imageio.ImageIO;

import org.w3c.dom.UserDataHandler;

import Model.BranchVo;
import Model.MemberVo;
import Model.MovieVo;
import Model.ScreenScheduleVo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import Controll.MainController;

public class SubController implements Initializable {
	@FXML
	private ImageView imageMovie;
	@FXML
	private ComboBox<String> cbTime;
	@FXML
	private ComboBox<String> cbAdult;
	@FXML
	private ComboBox<String> cbTeen;
	@FXML
	private ComboBox<String> cbChild;
	@FXML
	private ComboBox<String> cbSpecial;
	@FXML
	private Button btnChoice;
	@FXML
	private Label lblName;
	@FXML
	private Label lblEngName;
	@FXML
	private Label lblBranch;
	@FXML
	private Label lblCinema;
	@FXML
	private Label lblDate;
	@FXML
	private Label lblTime;
	@FXML
	private Label lblSeat;
	@FXML
	private Label lblPayment;
	@FXML
	private Button btnNext2;
	@FXML
	private Button btnCancle;
	@FXML
	private Button btnA1;
	@FXML
	private Button btnA2;
	@FXML
	private Button btnA3;
	@FXML
	private Button btnA4;
	@FXML
	private Button btnA5;
	@FXML
	private Button btnA6;
	@FXML
	private Button btnB1;
	@FXML
	private Button btnB2;
	@FXML
	private Button btnB3;
	@FXML
	private Button btnB4;
	@FXML
	private Button btnB5;
	@FXML
	private Button btnB6;
	@FXML
	private Button btnC1;
	@FXML
	private Button btnC2;
	@FXML
	private Button btnC3;
	@FXML
	private Button btnC4;
	@FXML
	private Button btnC5;
	@FXML
	private Button btnC6;
	@FXML
	private Button btnD1;
	@FXML
	private Button btnD2;
	@FXML
	private Button btnD3;
	@FXML
	private Button btnD4;
	@FXML
	private Button btnD5;
	@FXML
	private Button btnD6;

	private int payment1;
	private int payment2;
	private int payment3;
	private int payment4;

	private int seat1;
	private int seat2;
	private int seat3;
	private int seat4;
	ObservableList<String> timeData = FXCollections.observableArrayList();
	ObservableList<MemberVo> data = FXCollections.observableArrayList();

	File selectedFile = null;
	String localUrl = ""; // �̹��� ���� ���
	Image localImage;
	String selectFileName = "";

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		StaticData sd = new StaticData();
		localUrl = "/image/default.png";
		localImage = new Image(getClass().getResourceAsStream(localUrl));
		imageMovie.setImage(localImage);

		if (StaticData.date != null) {
			lblDate.setText(StaticData.date + "");
		}
		if (StaticData.branchVo != null) {
			lblBranch.setText(StaticData.branchVo.getBranchName());
		}
		if (StaticData.cinemaVo != null) {
			lblCinema.setText(StaticData.cinemaVo.getCinema());
		}
		if (StaticData.movieVo != null) {
			lblName.setText(StaticData.movieVo.getTitle());
			localUrl = "file:/C:/images/" + StaticData.movieVo.getPoster();
			localImage = new Image(localUrl, false);
			imageMovie.setImage(localImage);

		}
		if (StaticData.payment != null) {
			lblPayment.setText(StaticData.payment + "��");
			StaticData.payment2 = lblPayment.getText();
		}
		if (StaticData.time != null) {
			cbTime.setPromptText(StaticData.time);
			cbAdult.setPromptText(StaticData.adult);
			cbTeen.setPromptText(StaticData.teen);
			cbChild.setPromptText(StaticData.child);
			cbSpecial.setPromptText(StaticData.special);
			lblTime.setText(StaticData.time);
		}

		timeList();
		cbTime.setItems(timeData);
		cbAdult.setItems(FXCollections.observableArrayList("1", "2", "3", "4"));
		cbTeen.setItems(FXCollections.observableArrayList("1", "2", "3", "4"));
		cbChild.setItems(FXCollections.observableArrayList("1", "2", "3", "4"));
		cbSpecial.setItems(FXCollections.observableArrayList("1", "2", "3", "4"));

		cbTime.setOnAction(event -> {
			lblTime.setText(cbTime.getSelectionModel().getSelectedItem());
			StaticData.time = cbTime.getSelectionModel().getSelectedItem();
		});
		cbAdult.setOnAction(event -> {
			seat1 = (cbAdult.getSelectionModel().getSelectedIndex() + 1);
			StaticData.seat = seat1;
			payment1 = (cbAdult.getSelectionModel().getSelectedIndex() + 1) * StaticData.ADULT;
			StaticData.payment = payment1 + "";
			StaticData.adult = cbAdult.getSelectionModel().getSelectedItem();
		});
		cbTeen.setOnAction(event -> {
			seat2 = (cbTeen.getSelectionModel().getSelectedIndex() + 1);
			StaticData.seat = seat1 + seat2;
			payment2 = (cbTeen.getSelectionModel().getSelectedIndex() + 1) * StaticData.TEEN;
			StaticData.payment = (payment1 + payment2) + "";
			StaticData.teen = cbTeen.getSelectionModel().getSelectedItem();
		});
		cbChild.setOnAction(event -> {
			seat3 = (cbChild.getSelectionModel().getSelectedIndex() + 1);
			StaticData.seat = seat1 + seat2 + seat3;
			payment3 = (cbChild.getSelectionModel().getSelectedIndex() + 1) * StaticData.CHILD;
			StaticData.payment = (payment1 + payment2 + payment3) + "";
			StaticData.child = cbChild.getSelectionModel().getSelectedItem();
		});
		cbSpecial.setOnAction(event -> {
			seat4 = (cbSpecial.getSelectionModel().getSelectedIndex() + 1);
			StaticData.seat = seat1 + seat2 + seat3 + seat4;
			payment4 = (cbSpecial.getSelectionModel().getSelectedIndex() + 1) * StaticData.CHILD;
			StaticData.payment = (payment1 + payment2 + payment3 + payment4) + "";
			StaticData.special = cbSpecial.getSelectionModel().getSelectedItem();
		});

		for (int i = 0; i < StaticData.seat; i++) {
			if (StaticData.seat == 1) {
				resOne();
				memberSearch();

				btnA1.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnA1.getUserData() + "";
					btnA1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnA3.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnA3.getUserData() + "";
					btnA3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnA5.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnA5.getUserData() + "";
					btnA5.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnA6.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnA6.getUserData() + "";
					btnA6.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnB1.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnB1.getUserData() + "";
					btnB1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnB3.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnB3.getUserData() + "";
					btnB3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnB5.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnB5.getUserData() + "";
					btnB5.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnB6.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnB6.getUserData() + "";
					btnB6.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnC1.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnC1.getUserData() + "";
					btnC1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnC3.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnC3.getUserData() + "";
					btnC3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnC5.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnC5.getUserData() + "";
					btnC5.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnC6.setOnAction(event -> {
					btnC6.setDisable(true);
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnC6.getUserData() + "";
					btnC6.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnD1.setOnAction(event -> {
					btnD1.setDisable(true);
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnD1.getUserData() + "";
					btnD1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnD3.setOnAction(event -> {
					btnD3.setDisable(true);
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnD3.getUserData() + "";
					btnD3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnD5.setOnAction(event -> {
					btnD5.setDisable(true);
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnD5.getUserData() + "";
					btnD5.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnD6.setOnAction(event -> {
					disableButton();
					StaticData.seat--;
					StaticData.seatNumber = btnD6.getUserData() + "";
					btnD6.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
			} else if (StaticData.seat == 2) {
				resThree();
				memberSearch();
				btnA1.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 2;
					StaticData.seatNumber = btnA1.getUserData() + "," + btnA2.getUserData();
					btnA1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnA2.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnA3.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 2;
					StaticData.seatNumber = btnA3.getUserData() + "," + btnA4.getUserData();
					btnA3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnA4.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnB1.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 2;
					StaticData.seatNumber = btnB1.getUserData() + "," + btnB2.getUserData();
					btnB1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnB2.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnB3.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 2;
					StaticData.seatNumber = btnB3.getUserData() + "," + btnB4.getUserData();
					btnB3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnB4.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnC1.setOnAction(event -> {

					disableButton();
					StaticData.seat -= 2;
					StaticData.seatNumber = btnC1.getUserData() + "," + btnC2.getUserData();
					btnC1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnC2.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnC3.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 2;
					StaticData.seatNumber = btnC3.getUserData() + "," + btnC4.getUserData();
					btnC3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnC4.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnD1.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 2;
					StaticData.seatNumber = btnD1.getUserData() + "," + btnD2.getUserData();
					btnD1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnD2.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnD3.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 2;
					StaticData.seatNumber = btnD3.getUserData() + "," + btnD4.getUserData();
					btnD3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnD4.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
			} else if (StaticData.seat == 3) {
				resThree();
				memberSearch();
				btnA1.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 3;
					StaticData.seatNumber = btnA1.getUserData() + "," + btnA2.getUserData() + "," + btnA3.getUserData();
					btnA1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnA2.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnA3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnB1.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 3;
					StaticData.seatNumber = btnB1.getUserData() + "," + btnB2.getUserData() + "," + btnB3.getUserData();
					btnB1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnB2.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnB3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnC1.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 3;
					StaticData.seatNumber = btnC1.getUserData() + "," + btnC2.getUserData() + "," + btnC3.getUserData();
					btnC1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnC2.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnC3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnD1.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 3;
					StaticData.seatNumber = btnD1.getUserData() + "," + btnD2.getUserData() + "," + btnD3.getUserData();
					btnD1.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnD2.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnD3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnA3.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 3;
					StaticData.seatNumber = btnA3.getUserData() + "," + btnA4.getUserData() + "," + btnA5.getUserData();
					btnA3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnA4.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnA5.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnB3.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 3;
					StaticData.seatNumber = btnB3.getUserData() + "," + btnB4.getUserData() + "," + btnB5.getUserData();
					btnB3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnB4.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnB5.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnC3.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 3;
					StaticData.seatNumber = btnC3.getUserData() + "," + btnC4.getUserData() + "," + btnC5.getUserData();
					btnC3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnC4.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnC5.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
				btnD3.setOnAction(event -> {
					disableButton();
					StaticData.seat -= 3;
					StaticData.seatNumber = btnD3.getUserData() + "," + btnD4.getUserData() + "," + btnD5.getUserData();
					btnD3.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnD4.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					btnD5.setStyle("-fx-text-fill: white; -fx-background-color: linear-gradient(#000000, #000000); -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
					lblSeat.setText(StaticData.seatNumber);
				});
			} else {
				try {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("SeatRes");
					alert.setContentText("4�ڸ� �̻� ���� �Ұ��� ");
					alert.showAndWait();
					StaticData.seat = 0;
					FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Sub.fxml"));
					Parent mainView = (Parent) loader.load();
					Scene scene = new Scene(mainView);
					Stage mainMtage = new Stage();
					Stage oldStage = (Stage) btnNext2.getScene().getWindow();
					oldStage.close();
					mainMtage.setTitle("Main2");
					mainMtage.setScene(scene);
					mainMtage.show();
				} catch (Exception e) {
				}
			}
		}

		btnChoice.setOnAction(event -> {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Sub.fxml"));
				Parent mainView = (Parent) loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				Stage oldStage = (Stage) btnNext2.getScene().getWindow();
				oldStage.close();
				mainMtage.setTitle("Main2");
				mainMtage.setScene(scene);
				mainMtage.show();

			} catch (IOException e) {
				System.out.println("����" + e);
			}
		});

		btnNext2.setOnAction(event -> {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Member.fxml"));
				Parent mainView = (Parent) loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				Stage oldStage = (Stage) btnNext2.getScene().getWindow();
				oldStage.close();
				mainMtage.setTitle("Main2");
				mainMtage.setScene(scene);
				mainMtage.show();

			} catch (IOException e) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� ����");
				alert.setHeaderText("��ȭ ������ �����ϴ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
		});

		btnCancle.setOnAction(event -> {
			try {
				sd.reset();
				StaticData.seat = 0;
				StaticData.seatNumber = null;
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Main.fxml"));
				Parent mainView = (Parent) loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				Stage oldStage = (Stage) btnCancle.getScene().getWindow();
				oldStage.close();
				mainMtage.setTitle("Main");
				mainMtage.setScene(scene);
				mainMtage.show();
			} catch (Exception e) {

			}
		});
	}

	public void timeList() {
		// TODO Auto-generated method stub
		ScreenScheduleDAO sDao = new ScreenScheduleDAO();
		ScreenScheduleVo sVo = new ScreenScheduleVo();
		ArrayList<ScreenScheduleVo> time;

		time = sDao.getTimeSearch();
		for (int index = 0; index < time.size(); index++) {
			sVo = time.get(index);

			if (sVo.getB_Screen().equals(StaticData.branchVo.getBranchName())) {
				if (sVo.getC_Screen().equals(StaticData.cinemaVo.getCinema())) {
					if (sVo.getM_Screen().equals(StaticData.movieVo.getTitle())) {
						timeData.addAll(sVo.getScreenTime());
					}
				}
			}
		}
	}

	public void resOne() {
		btnA2.setDisable(true);
		btnB2.setDisable(true);
		btnC2.setDisable(true);
		btnD2.setDisable(true);
		btnA4.setDisable(true);
		btnB4.setDisable(true);
		btnC4.setDisable(true);
		btnD4.setDisable(true);
	}

	public void resThree() {
		btnA2.setDisable(true);
		btnB2.setDisable(true);
		btnC2.setDisable(true);
		btnD2.setDisable(true);
		btnA4.setDisable(true);
		btnB4.setDisable(true);
		btnC4.setDisable(true);
		btnD4.setDisable(true);
		btnA5.setDisable(true);
		btnB5.setDisable(true);
		btnC5.setDisable(true);
		btnD5.setDisable(true);
		btnA6.setDisable(true);
		btnB6.setDisable(true);
		btnC6.setDisable(true);
		btnD6.setDisable(true);
	}

	public void resOneCancle() {
		btnA2.setDisable(false);
		btnB2.setDisable(false);
		btnC2.setDisable(false);
		btnD2.setDisable(false);
		btnA4.setDisable(false);
		btnB4.setDisable(false);
		btnC4.setDisable(false);
		btnD4.setDisable(false);
	}

	public void disableButton() {
		btnA1.setDisable(true);
		btnA2.setDisable(true);
		btnA3.setDisable(true);
		btnA4.setDisable(true);
		btnA5.setDisable(true);
		btnA6.setDisable(true);
		btnB1.setDisable(true);
		btnB2.setDisable(true);
		btnB3.setDisable(true);
		btnB4.setDisable(true);
		btnB5.setDisable(true);
		btnB6.setDisable(true);
		btnC1.setDisable(true);
		btnC2.setDisable(true);
		btnC3.setDisable(true);
		btnC4.setDisable(true);
		btnC5.setDisable(true);
		btnC6.setDisable(true);
		btnD1.setDisable(true);
		btnD2.setDisable(true);
		btnD3.setDisable(true);
		btnD4.setDisable(true);
		btnD5.setDisable(true);
		btnD6.setDisable(true);
	}

	public void memberSearch() {
		MemberDAO mDao = new MemberDAO();
		MemberVo mVo = new MemberVo();
		ArrayList<MemberVo> list;

		list = mDao.getMemberTotal();
		for (int index = 0; index < list.size(); index++) {
			mVo = list.get(index);
			if (mVo.getSeat() != null && mVo.getDay() != null && mVo.getTitle() != null) {
				if (mVo.getSeat().equals(btnA1.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnA1.setDisable(true);
				if (mVo.getSeat().equals(btnA2.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnA2.setDisable(true);
				if (mVo.getSeat().equals(btnA3.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnA3.setDisable(true);
				if (mVo.getSeat().equals(btnA4.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnA4.setDisable(true);
				if (mVo.getSeat().equals(btnA5.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnA5.setDisable(true);
				if (mVo.getSeat().equals(btnA6.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnA6.setDisable(true);

				if (mVo.getSeat().equals(btnB1.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnB1.setDisable(true);
				if (mVo.getSeat().equals(btnB2.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnB2.setDisable(true);
				if (mVo.getSeat().equals(btnB3.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnB3.setDisable(true);
				if (mVo.getSeat().equals(btnB4.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnB4.setDisable(true);
				if (mVo.getSeat().equals(btnB5.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnB5.setDisable(true);
				if (mVo.getSeat().equals(btnB6.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnB6.setDisable(true);

				if (mVo.getSeat().equals(btnC1.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnC1.setDisable(true);
				if (mVo.getSeat().equals(btnC2.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnC2.setDisable(true);
				if (mVo.getSeat().equals(btnC3.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnC3.setDisable(true);
				if (mVo.getSeat().equals(btnC4.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnC4.setDisable(true);
				if (mVo.getSeat().equals(btnC5.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnC5.setDisable(true);
				if (mVo.getSeat().equals(btnC6.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnC6.setDisable(true);

				if (mVo.getSeat().equals(btnD1.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnD1.setDisable(true);
				if (mVo.getSeat().equals(btnD2.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnD2.setDisable(true);
				if (mVo.getSeat().equals(btnD3.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnD3.setDisable(true);
				if (mVo.getSeat().equals(btnD4.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnD4.setDisable(true);
				if (mVo.getSeat().equals(btnD5.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnD5.setDisable(true);
				if (mVo.getSeat().equals(btnD6.getUserData()) && mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle()))
					btnD6.setDisable(true);

				if (mVo.getSeat().equals(btnA1.getUserData() + "," + btnA2.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnA1.setDisable(true);
					btnA2.setDisable(true);
				}
				if (mVo.getSeat().equals(btnA3.getUserData() + "," + btnA4.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnA3.setDisable(true);
					btnA4.setDisable(true);
				}
				if (mVo.getSeat().equals(btnB1.getUserData() + "," + btnB2.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnB1.setDisable(true);
					btnB2.setDisable(true);
				}
				if (mVo.getSeat().equals(btnB3.getUserData() + "," + btnB4.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnB3.setDisable(true);
					btnB4.setDisable(true);
				}
				if (mVo.getSeat().equals(btnC1.getUserData() + "," + btnC2.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnC1.setDisable(true);
					btnC2.setDisable(true);
				}
				if (mVo.getSeat().equals(btnC3.getUserData() + "," + btnC4.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnC3.setDisable(true);
					btnC4.setDisable(true);
				}
				if (mVo.getSeat().equals(btnD1.getUserData() + "," + btnD2.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnD1.setDisable(true);
					btnD2.setDisable(true);
				}
				if (mVo.getSeat().equals(btnD3.getUserData() + "," + btnD4.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnD3.setDisable(true);
					btnD4.setDisable(true);
				}

				if (mVo.getSeat().equals(btnA1.getUserData() + "," + btnA2.getUserData() + "," + btnA3.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnA1.setDisable(true);
					btnA2.setDisable(true);
					btnA3.setDisable(true);
				}
				if (mVo.getSeat().equals(btnA3.getUserData() + "," + btnA4.getUserData() + "," + btnA5.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnA3.setDisable(true);
					btnA4.setDisable(true);
					btnA5.setDisable(true);
				}
				if (mVo.getSeat().equals(btnB1.getUserData() + "," + btnB2.getUserData() + "," + btnB3.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnB1.setDisable(true);
					btnB2.setDisable(true);
					btnB3.setDisable(true);
				}
				if (mVo.getSeat().equals(btnB3.getUserData() + "," + btnB4.getUserData() + "," + btnB5.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnB3.setDisable(true);
					btnB4.setDisable(true);
					btnB5.setDisable(true);
				}
				if (mVo.getSeat().equals(btnC1.getUserData() + "," + btnC2.getUserData() + "," + btnC3.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnC1.setDisable(true);
					btnC2.setDisable(true);
					btnC3.setDisable(true);
				}
				if (mVo.getSeat().equals(btnC3.getUserData() + "," + btnC4.getUserData() + "," + btnC5.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnC3.setDisable(true);
					btnC4.setDisable(true);
					btnC5.setDisable(true);
				}
				if (mVo.getSeat().equals(btnD1.getUserData() + "," + btnD2.getUserData() + "," + btnD3.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnD1.setDisable(true);
					btnD2.setDisable(true);
					btnD3.setDisable(true);
				}
				if (mVo.getSeat().equals(btnD3.getUserData() + "," + btnD4.getUserData() + "," + btnD5.getUserData())
						&& mVo.getDay().equals(StaticData.date + "") && mVo.getTitle().equals(StaticData.movieVo.getTitle())) {
					btnD3.setDisable(true);
					btnD4.setDisable(true);
					btnD5.setDisable(true);
				}

			}
			data.addAll(data);

		}
	}
}