package Controll;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class Receipt implements Initializable {

	@FXML private ImageView imageRMovie;
	@FXML private Label lblRName;
	@FXML private Label lblRBranch;
	@FXML private Label lblRCinema;
	@FXML private Label lblRDate;
	@FXML private Label lblRTime;
	@FXML private Label lblRSeat;
	@FXML private Label lblRPayment;
	@FXML private Button btnRCheck;
	
	File selectedFile = null;
	String localUrl = ""; // �̹��� ���� ���
	Image localImage;
	String selectFileName = "";
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		localUrl = "/image/default.png";
		localImage = new Image(getClass().getResourceAsStream(localUrl));
		imageRMovie.setImage(localImage);

		if (StaticData.date != null) {
			lblRDate.setText(StaticData.date + "");
		}
		if (StaticData.branchVo != null) {
			lblRBranch.setText(StaticData.branchVo.getBranchName());
		}
		if (StaticData.cinemaVo != null) {
			lblRCinema.setText(StaticData.cinemaVo.getCinema());
		}
		if (StaticData.movieVo != null) {
			lblRName.setText(StaticData.movieVo.getTitle());
			localUrl = "file:/C:/images/" + StaticData.movieVo.getPoster();
			localImage = new Image(localUrl, false);
			imageRMovie.setImage(localImage);

		}
		
		lblRPayment.setText(StaticData.payment2);
		
		btnRCheck.setOnAction(event ->{
			Stage oldStage = (Stage)btnRCheck.getScene().getWindow();
			oldStage.close();
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Main.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("Main");
				mainMtage.setScene(scene);
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}
		});
	}

}
