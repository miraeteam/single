package Controll;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.BranchVo;
import Model.CinemaVo;
import Model.MovieVo;
import Controll.DBUtil;

public class BranchDAO {
	//���� db ���ε�
	public BranchVo getBranchUpload(BranchVo bvo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into Branch");
		sql.append(" values (branch_seq.nextval, ?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		BranchVo bVo = bvo;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, bVo.getBranchName());
			

			int i = pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("e = / " + e);
		} catch (Exception e) {
			System.out.println("e = / " + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {

			}
		}
		return bVo;
	}
	
	public ArrayList<BranchVo> getBranchSearch(){
		ArrayList<BranchVo> list = new ArrayList<BranchVo>();
		StringBuffer sql = new StringBuffer();
		sql.append("select b_name ");
		sql.append(" from branch ");
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BranchVo bVo = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				bVo = new BranchVo();
				bVo.setBranchName(rs.getString("b_name"));
				
				list.add(bVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return list;
	}
	public ArrayList<BranchVo> getCBranchSearch(){
		ArrayList<BranchVo> list = new ArrayList<BranchVo>();
		StringBuffer sql = new StringBuffer();
		sql.append("select b_name ");
		sql.append(" from branch ");
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BranchVo bVo = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				bVo = new BranchVo();
				bVo.setBranchName(rs.getString("b_name"));
				
				list.add(bVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return list;
	}
	public BranchVo getBranch(String branch) {
		StringBuffer sql = new StringBuffer();
		sql.append("select b_number, b_name ");
		sql.append(" from branch where b_name=? order by b_number");

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		BranchVo bVo = new BranchVo();
		try {
			con = DBUtil.getConnection();
			ps = con.prepareStatement(sql.toString());
			ps.setString(1, branch);
			rs = ps.executeQuery();
			while (rs.next()) {
				bVo = new BranchVo(rs.getString(1), rs.getString(2));
			
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return bVo;
	}
}
