package Controll;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.BranchVo;
import Model.CinemaVo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class CinemaController implements Initializable {
	@FXML private TextField txtCinema;
	@FXML private Button btnCinemaUploadOk;
	@FXML private ComboBox<String> cbCinema ;
	String branch1;
	String branch2;
	String branch3;
	String branch4;
	ObservableList<CinemaVo> data = FXCollections.observableArrayList();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		branchTitle();
		cbCinema.setItems(FXCollections.observableArrayList(branch1,branch2,branch3,branch4));
		btnCinemaUploadOk.setOnAction(event -> {
			try {
				data.removeAll(data);
				CinemaVo cVo = null;
				CinemaDAO cDAO = new CinemaDAO();
				
				if(event.getSource().equals(btnCinemaUploadOk)) {
					cVo = new CinemaVo(txtCinema.getText(), cbCinema.getSelectionModel().getSelectedItem());
					cDAO = new CinemaDAO();
					cDAO.getCinemaUpload(cVo);
					if(cDAO != null) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("�󿵰� �Է�");
						alert.setHeaderText(txtCinema.getText() + " �󿵰��� ������ ���������� �߰��Ǿ����ϴ�..");
						/*Stage oldStage = (Stage)btnCinemaUploadOk.getScene().getWindow();
						oldStage.close();*/
						FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Main.fxml"));
						Parent mainView = (Parent) loader.load();
						Scene scene = new Scene(mainView);
						Stage mainMtage = new Stage();
						Stage oldStage = (Stage)btnCinemaUploadOk.getScene().getWindow();
						oldStage.close();
						mainMtage.setTitle("Cinema");
						mainMtage.setScene(scene);
						mainMtage.show();
					}
				}
			}catch(Exception ie) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �Է�");
				alert.setHeaderText("������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
			
		});
	}
	public void branchTitle() {
		BranchDAO bDao = new BranchDAO();
		BranchVo bVo = new BranchVo();
		ArrayList<BranchVo> list;

		list = bDao.getCBranchSearch();
		int rowCount = list.size();
		for (int index = 0; index < rowCount; index++) {
			bVo = list.get(index);
			switch(index) {
				case 0:
					branch1 = bVo.getBranchName();
					break;
				case 1:
					branch2 = bVo.getBranchName();
					break;
				case 2:
					branch3 = bVo.getBranchName();
					break;
				case 3:
					branch4 = bVo.getBranchName();
					break;
				
			}
			
		}
	}

}
