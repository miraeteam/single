package Controll;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.MovieVo;
import Model.ScreenScheduleVo;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class ScreenScheduleDAO {
	public ScreenScheduleVo getScreenTimeUpload(ScreenScheduleVo svo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into screenschedule");
		sql.append(" values (screenschedule_seq.nextval,?, ?, ?, ? )");

		Connection con = null;
		PreparedStatement pstmt = null;
		ScreenScheduleVo sVo = svo;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, sVo.getScreenTime());
			pstmt.setString(2, sVo.getB_Screen());
			pstmt.setString(3, sVo.getM_Screen());
			pstmt.setString(4, sVo.getC_Screen());

			int i = pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("e = / " + e);
		} catch (Exception e) {
			System.out.println("e = / " + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {

			}
		}
		return sVo;
	}

	public ArrayList<ScreenScheduleVo> getTimeSearch() {
		ArrayList<ScreenScheduleVo> list = new ArrayList<ScreenScheduleVo>();
		StringBuffer sql = new StringBuffer();
		sql.append("select s_number, s_screentime, b_name, m_title, c_cinema ");
		sql.append(" from ScreenSchedule order by s_number");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ScreenScheduleVo sVo = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				sVo = new ScreenScheduleVo();
				sVo.setScreenNumner(rs.getString("s_number"));
				sVo.setScreenTime(rs.getString("s_screentime"));
				sVo.setB_Screen(rs.getString("b_name"));
				sVo.setM_Screen(rs.getString("m_title"));
				sVo.setC_Screen(rs.getString("c_cinema"));

				list.add(sVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return list;
	}

	public ScreenScheduleVo getTime(String time) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * ");
		sql.append(" from screenschedule where b_name order by m_number");

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ScreenScheduleVo sVo = new ScreenScheduleVo();
		try {
			con = DBUtil.getConnection();
			ps = con.prepareStatement(sql.toString());
			ps.setString(1, time);
			rs = ps.executeQuery();
			while (rs.next()) {
				sVo = new ScreenScheduleVo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));

			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return sVo;
	}
	
	public void getTimeDelete(String number,String branch, String title, String cinema) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from screenschedule where s_number=? and b_name=? and m_title=? and c_cinema=? ");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, number);
			pstmt.setString(2, branch);
			pstmt.setString(3, title);
			pstmt.setString(4, cinema);
			
			int i = pstmt.executeUpdate();
			System.out.println(i);
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ð� ����");
				alert.setHeaderText("�ð� ���� �Ϸ�");
				alert.setContentText("�ð� ���� ���� !!");
				alert.showAndWait();

			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ð� ����");
				alert.setHeaderText("�ð� ���� ����");
				alert.setContentText("�ð� ���� ���� !!");
				alert.showAndWait();

			}
		} catch (SQLException e) {
			System.out.println("e = [" + e + " ] ");
		} catch (Exception e) {
			System.out.println("e = [" + e + " ] ");
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {

			}
		}
	}

}
