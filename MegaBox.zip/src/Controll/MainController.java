package Controll;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.MovieVo;
import Model.BranchVo;
import Model.CinemaVo;
import Model.MemberVo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class MainController implements Initializable {
	@FXML
	private DatePicker dpDate;
	@FXML
	private Button btnMLogin;
	@FXML
	ToggleGroup movieGroup;
	@FXML
	ToggleGroup cinemaGroup;
	@FXML
	ToggleGroup roomGroup;
	@FXML
	private ToggleButton btnCinema1;
	@FXML
	private ToggleButton btnCinema2;
	@FXML
	private ToggleButton btnCinema3;
	@FXML
	private ToggleButton btnCinema4;
	@FXML
	private ToggleButton btnMovie1;
	@FXML
	private ToggleButton btnMovie2;
	@FXML
	private ToggleButton btnMovie3;
	@FXML
	private ToggleButton btnMovie4;
	@FXML
	private ToggleButton btnMovie5;
	@FXML
	private ToggleButton btnRoom1;
	@FXML
	private ToggleButton btnRoom2;
	@FXML
	private ToggleButton btnRoom3;
	@FXML
	private Button btnNext;
	@FXML
	private Label lblBranch;
	@FXML
	private Label lblCheck1;
	@FXML
	private Label lblCheck2;
	@FXML
	private Label lblCheck3;

	private String movie1;
	private String movie2;
	private String movie3;
	private String movie4;
	private String movie5;

	File selectedFile = null;
	String localUrl = ""; // �̹��� ���� ���
	Image localImage;
	String selectFileName = "";
	ObservableList<MovieVo> data = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

			dpDate.setValue(LocalDate.now());
			btnMLogin.setOnAction(event -> handlerBtnMLoginAction(event));
			posterList();

			btnCinema1.setOnAction(event -> {
				BranchVo bVo = new BranchVo();
				BranchDAO bDao = new BranchDAO();

				bVo = bDao.getBranch("����");
				StaticData.branchVo = bVo;
				btnRoom1.setText("1��");
				btnRoom2.setText("2��");
				btnRoom3.setText("3��");

				lblCheck1.setText(btnCinema1.getText());
			});
			btnCinema2.setOnAction(event -> {
				BranchVo bVo = new BranchVo();
				BranchDAO bDao = new BranchDAO();

				bVo = bDao.getBranch("�������");
				StaticData.branchVo = bVo;
				btnRoom1.setText("1�󿵰�");
				btnRoom2.setText("2�󿵰�");
				btnRoom3.setText("3�󿵰�");
				lblCheck1.setText(btnCinema2.getText());
			});
			btnCinema3.setOnAction(event -> {
				BranchVo bVo = new BranchVo();
				BranchDAO bDao = new BranchDAO();

				bVo = bDao.getBranch("��Ʈ��");
				StaticData.branchVo = bVo;
				btnRoom1.setText("A");
				btnRoom2.setText("B");
				btnRoom3.setText("C");
				lblCheck1.setText(btnCinema3.getText());
			});
			btnCinema4.setOnAction(event -> {
				BranchVo bVo = new BranchVo();
				BranchDAO bDao = new BranchDAO();

				bVo = bDao.getBranch("�ڿ���");
				StaticData.branchVo = bVo;
				btnRoom1.setText("A��");
				btnRoom2.setText("B��");
				btnRoom3.setText("C��");

				lblCheck1.setText(btnCinema4.getText());
			});
			btnRoom1.setOnAction(event -> {
				CinemaVo cVo = new CinemaVo();
				CinemaDAO cDao = new CinemaDAO();

				cVo = cDao.getCinema(btnRoom1.getText());

				StaticData.cinemaVo = cVo;
				lblCheck2.setText(btnRoom1.getText());
			});
			btnRoom2.setOnAction(event -> {
				CinemaVo cVo = new CinemaVo();
				CinemaDAO cDao = new CinemaDAO();
				cVo = cDao.getCinema(btnRoom2.getText());
				StaticData.cinemaVo = cVo;
				lblCheck2.setText(btnRoom2.getText());
			});
			btnRoom3.setOnAction(event -> {
				CinemaVo cVo = new CinemaVo();
				CinemaDAO cDao = new CinemaDAO();
				cVo = cDao.getCinema(btnRoom3.getText());
				StaticData.cinemaVo = cVo;
				lblCheck2.setText(btnRoom3.getText());
			});
			btnMovie1.setOnAction(event -> {
				MovieVo mVo = new MovieVo();
				MovieDAO mDao = new MovieDAO();
				mVo = mDao.getMovieAll(movie1);

				StaticData.movieVo = mVo;
				lblCheck3.setText(mVo.getTitle());
			});
			btnMovie2.setOnAction(event -> {
				MovieVo mVo = new MovieVo();
				MovieDAO mDao = new MovieDAO();
				mVo = mDao.getMovieAll(movie2);

				StaticData.movieVo = mVo;
				lblCheck3.setText(mVo.getTitle());
			});
			btnMovie3.setOnAction(event -> {
				MovieVo mVo = new MovieVo();
				MovieDAO mDao = new MovieDAO();
				mVo = mDao.getMovieAll(movie3);

				StaticData.movieVo = mVo;
				lblCheck3.setText(mVo.getTitle());
			});
			btnMovie4.setOnAction(event -> {
				MovieVo mVo = new MovieVo();
				MovieDAO mDao = new MovieDAO();
				mVo = mDao.getMovieAll(movie4);

				StaticData.movieVo = mVo;
				lblCheck3.setText(mVo.getTitle());
			});
			btnMovie5.setOnAction(event -> {
				MovieVo mVo = new MovieVo();
				MovieDAO mDao = new MovieDAO();
				mVo = mDao.getMovieAll(movie5);

				StaticData.movieVo = mVo;
				lblCheck3.setText(mVo.getTitle());
			});
		
		// ����â ������ư
		btnNext.setOnAction(event -> {
			try {
				StaticData.date = dpDate.getValue();
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Sub.fxml"));
				Parent mainView = (Parent) loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				Stage oldStage = (Stage) btnNext.getScene().getWindow();
				oldStage.close();
				mainMtage.setTitle("Member");
				mainMtage.setScene(scene);
				mainMtage.show();

			} catch (IOException e) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("����, �󿵰�, ��ȭ���� ����");
				alert.setHeaderText("����, �󿵰�, ��ȭ������ �����ϼ���");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
		});

	}

	// ������ �α��� ��ư
	public void handlerBtnMLoginAction(ActionEvent event) {
		// TODO Auto-generated method stub
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/login.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			Stage oldStage = (Stage) btnMLogin.getScene().getWindow();
			oldStage.close();
			mainMtage.setTitle("Manager Login");
			mainMtage.setScene(scene);
			mainMtage.show();

		} catch (IOException e) {
			System.out.println("����" + e);
		}
	}

	/*
	 * public void handlerBtnMovieAction(ActionEvent event) { // TODO Auto-generated
	 * method stub try { FXMLLoader loader = new
	 * FXMLLoader(getClass().getResource("/View/Movie.fxml")); Parent mainView =
	 * (Parent)loader.load(); Scene scene = new Scene(mainView); Stage mainMtage =
	 * new Stage(); mainMtage.setTitle("Movie"); mainMtage.setScene(scene);
	 * mainMtage.show();
	 * 
	 * } catch(IOException e) { System.out.println("����" + e); } }
	 */
	public void posterList() {
		MovieDAO mDao = new MovieDAO();
		MovieVo mVo = new MovieVo();
		ArrayList<MovieVo> list;

		list = mDao.getMoviePoster();
		for (int index = 0; index < list.size(); index++) {
			mVo = list.get(index);
			if (index == 0) {
				localUrl = "file:/C:/images/" + mVo.getPoster();
				localImage = new Image(localUrl, false);
				btnMovie1.setGraphic(new ImageView(localImage));
				btnMovie1.setUserData(mVo.getTitle());
				movie1 = btnMovie1.getUserData() + "";
			}
			if (index == 1) {
				localUrl = "file:/C:/images/" + mVo.getPoster();
				localImage = new Image(localUrl, false);
				btnMovie2.setGraphic(new ImageView(localImage));
				btnMovie2.setUserData(mVo.getTitle());
				movie2 = btnMovie2.getUserData() + "";
			}
			if (index == 2) {
				localUrl = "file:/C:/images/" + mVo.getPoster();
				localImage = new Image(localUrl, false);
				btnMovie3.setGraphic(new ImageView(localImage));
				btnMovie3.setUserData(mVo.getTitle());
				movie3 = btnMovie3.getUserData() + "";
			}
			if (index == 3) {
				localUrl = "file:/C:/images/" + mVo.getPoster();
				localImage = new Image(localUrl, false);
				btnMovie4.setGraphic(new ImageView(localImage));
				btnMovie4.setUserData(mVo.getTitle());
				movie4 = btnMovie4.getUserData() + "";
			}
			if (index == 4) {
				localUrl = "file:/C:/images/" + mVo.getPoster();
				localImage = new Image(localUrl, false);
				btnMovie5.setGraphic(new ImageView(localImage));
				btnMovie5.setUserData(mVo.getTitle());
				movie5 = btnMovie5.getUserData() + "";

			}
		}
	}
}
