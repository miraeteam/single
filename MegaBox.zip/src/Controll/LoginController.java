package Controll;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController implements Initializable {
	@FXML private TextField txtId;
	@FXML private PasswordField txtPassword;
	@FXML private Button btnCancel;
	@FXML private Button btnLogin;
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		btnLogin.setOnAction(event -> handlerBtnLoginAction(event));
		btnCancel.setOnAction(event -> handlerBtnCancelAction(event));
	}


	public void handlerBtnCancelAction(ActionEvent event) {
		// TODO Auto-generated method stub
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Main.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			Stage oldStage = (Stage)btnCancel.getScene().getWindow();
			oldStage.close();
			mainMtage.setTitle("Member");
			mainMtage.setScene(scene);
			mainMtage.show();
			}catch(Exception e){
				
			}
	}


	public void handlerBtnLoginAction(ActionEvent event) {
		// TODO Auto-generated method stub
		Alert alert;
		if(txtId.getText().equals("1") || txtPassword.getText().equals("1")) {
			alert = new Alert(AlertType.WARNING);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("���̵�� ��й�ȣ ���Է�");
			alert.setContentText("���̵�� ��й�ȣ�� �Է����� ���� �׸��� �ֽ��ϴ�." + "\n �ٽ� ����� �Է��ϼ���");
			alert.setResizable(false);
			alert.showAndWait();
			return;
		}
		if(txtId.getText().equals("") || txtPassword.getText().equals("")) {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ManagerInfo.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("Manager");
				mainMtage.setScene(scene);
				Stage oldStage = (Stage)btnLogin.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}
		} else {
			alert = new Alert(AlertType.WARNING);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("���̵�� ��й�ȣ ����ġ");
			alert.setContentText("���̵�� ��й�ȣ�� ��ġ���� �ʽ��ϴ�." + "\n�ٽ� ����� �Է��ϼ��� ");
			alert.show();
		}

	}

}
