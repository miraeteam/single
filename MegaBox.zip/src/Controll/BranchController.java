package Controll;

import java.net.URL;
import java.util.ResourceBundle;

import Model.BranchVo;
import Model.MovieVo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class BranchController implements Initializable {
	@FXML TextField txtBranchName;
	@FXML Button btnBranchUploadOk;
	ObservableList<BranchVo> data = FXCollections.observableArrayList();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		btnBranchUploadOk.setOnAction(event -> {
			try {
				data.removeAll(data);
				BranchVo bVo = null;
				BranchDAO bDAO = new BranchDAO();
				
				if(event.getSource().equals(btnBranchUploadOk)) {
					bVo = new BranchVo(txtBranchName.getText());
					bDAO = new BranchDAO();
					bDAO.getBranchUpload(bVo);
					if(bDAO != null) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("���� �̸� �Է�");
						alert.setHeaderText(txtBranchName.getText() + " ������ ������ ���������� �߰��Ǿ����ϴ�..");
						alert.setContentText("���� ������ �Է��ϼ���");
						
						txtBranchName.clear();
						
						FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Main.fxml"));
						Parent mainView = (Parent) loader.load();
						Scene scene = new Scene(mainView);
						Stage mainMtage = new Stage();
						Stage oldStage = (Stage)btnBranchUploadOk.getScene().getWindow();
						oldStage.close();
						mainMtage.setTitle("Branch");
						mainMtage.setScene(scene);
						mainMtage.show();
					}
				}
			}catch(Exception ie) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �Է�");
				alert.setHeaderText("������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
			
		});
	}

}
