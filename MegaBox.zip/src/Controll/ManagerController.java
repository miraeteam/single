package Controll;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.MovieVo;
import Controll.MovieDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.FileChooser.ExtensionFilter;

public class ManagerController implements Initializable {
	@FXML
	private ImageView imagePoster;
	@FXML
	private TextField txtMovieTitle;
	@FXML
	private TextField txtMovieRate;
	@FXML
	private TextField txtMoviePremier;
	@FXML
	private TextField txtDirector;
	@FXML
	private TextField txtStaff;
	@FXML
	private TextField txtMovieGenre;
	@FXML
	private TextField txtType;
	@FXML
	private TextArea txtMovieStory;
	@FXML
	private TextField txtScreenTime;
	@FXML
	private Button btnPosterUpload;
	@FXML
	private Button btnMovieUploadOk;
	@FXML
	private Button btnMovieUploadCancle;

	private Stage primaryStage;
	private File dirSave = new File("C:/images");
	File selectedFile = null;
	String localUrl = ""; // �̹��� ���� ���
	Image localImage;
	String selectFileName = "";
	ObservableList<MovieVo> data = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

		localUrl = "/image/default.png";
		localImage = new Image(localUrl, false);
		imagePoster.setImage(localImage);
		
		btnMovieUploadCancle.setOnAction(event -> {
			Stage oldStage = (Stage)btnMovieUploadCancle.getScene().getWindow();
			oldStage.close();
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ManagerInfo.fxml"));
				Parent mainView = (Parent)loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("Manager");
				mainMtage.setScene(scene);
				mainMtage.show();
			} catch(IOException e) {
				System.out.println("����" + e);
			}

		});
		btnPosterUpload.setOnAction(event -> { 
			FileChooser fileChooser = new FileChooser();
			fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Image File", "*.png", "*.jpg", "*.gif"));
			try {
				selectedFile = fileChooser.showOpenDialog(primaryStage);
				if (selectedFile != null) {
					// �̹��� ���� ���
					localUrl = selectedFile.toURI().toURL().toString();
				}
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			localImage = new Image(localUrl, false);
			imagePoster.setImage(localImage);
			imagePoster.setFitHeight(170);
			imagePoster.setFitWidth(100);
			if (selectedFile != null) {
				selectFileName = selectedFile.getName();
			}
		});
		
		btnMovieUploadOk.setOnAction(event -> {
			try {
				data.removeAll(data);
				MovieVo mVo = null;
				MovieDAO mDao = new MovieDAO();
				File dirMake = new File(dirSave.getAbsolutePath());
				// ������ �̹��� ���� ���� ����
				if (!dirMake.exists()) {
					dirMake.mkdir();
				}
				// �̹��� ���� ����
				String fileName = imageSave(selectedFile);
				// ��ȭ ���� ����
				if (event.getSource().equals(btnMovieUploadOk)) {
					mVo = new MovieVo(txtMovieTitle.getText(), txtMovieRate.getText(), txtMoviePremier.getText(),
							txtDirector.getText(), txtStaff.getText(), txtScreenTime.getText(), txtMovieGenre.getText(),
							txtType.getText(), txtMovieStory.getText(), fileName);
					mDao = new MovieDAO();
					mDao.getMovieUpload(mVo);
					if(mDao != null) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("��ȭ ���� �Է�");
						alert.setHeaderText(txtMovieTitle.getText() + " ��ȭ�� ������ ���������� �߰��Ǿ����ϴ�..");
						alert.setContentText("���� ��ȭ������ �Է��ϼ���");
						
						// �⺻ �̹���
						localUrl = "/image/default.png";
						localImage = new Image(localUrl, false);
						imagePoster.setImage(localImage);
						alert.showAndWait();
						txtMovieTitle.clear();
						txtMovieRate.clear();
						txtMoviePremier.clear();
						txtDirector.clear();
						txtStaff.clear();
						txtScreenTime.clear();
						txtMovieGenre.clear();
						txtType.clear();
						txtMovieStory.clear();
						
						FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Main.fxml"));
						Parent mainView = (Parent) loader.load();
						Scene scene = new Scene(mainView);
						Stage mainMtage = new Stage();
						Stage oldStage = (Stage)btnMovieUploadOk.getScene().getWindow();
						oldStage.close();
						mainMtage.setTitle("Member");
						mainMtage.setScene(scene);
						mainMtage.show();
						
						
					}

				}
			} catch (Exception ie) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��ȭ ���� �Է�");
				alert.setHeaderText("��ȭ ������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
			
		});
	}
	//�̹��� ���� ���� ����
	public String imageSave(File file) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		int data = -1;
		String fileName = null;
		try {
			// �̹��� ���ϸ� ����
			fileName = "Movie" + System.currentTimeMillis() + "_" + file.getName();
			bis = new BufferedInputStream(new FileInputStream(file));
			bos = new BufferedOutputStream(new FileOutputStream(dirSave.getAbsolutePath() + "\\" + fileName));
			// ������ �̹��� ���� InputStream�� �������� �̸����� ���� -1
			while ((data = bis.read()) != -1) {
				bos.write(data);
				bos.flush();
			}
		} catch (Exception e) {
			e.getMessage();
		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
				if (bis != null) {
					bis.close();
				}
			} catch (IOException e) {
				e.getMessage();
			}
		}
		return fileName;
	}

}
