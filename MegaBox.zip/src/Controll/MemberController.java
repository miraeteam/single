package Controll;

import java.net.URL;
import java.util.ResourceBundle;

import Model.MemberVo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class MemberController implements Initializable {
	@FXML
	private Button btnReserveOk;
	@FXML
	private Button btnReserveCancle;
	@FXML
	private TextField txtMemberName;
	@FXML
	private TextField txtMemberBirth;
	@FXML
	private TextField txtMemberPhone1;
	@FXML
	private TextField txtMemberPhone2;
	@FXML
	private TextField txtMemberPhone3;
	@FXML
	private PasswordField password;
	@FXML
	private PasswordField passwordOk;
	@FXML
	private Label lblMSeat;
	@FXML
	private Label lblMDate;
	@FXML
	private Label lblMMovie;

	ObservableList<MemberVo> data = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		StaticData sd = new StaticData();
		if (StaticData.seatNumber != null) {
			lblMSeat.setText(StaticData.seatNumber);
		}
		lblMDate.setText(StaticData.date + "");
		lblMMovie.setText(StaticData.movieVo.getTitle());
		btnReserveCancle.setOnAction(event -> {
			try {
				sd.reset();
				StaticData.seat = 0;
				StaticData.seatNumber = null;
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Main.fxml"));
				Parent mainView = (Parent) loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				Stage oldStage = (Stage) btnReserveCancle.getScene().getWindow();
				oldStage.close();
				mainMtage.setTitle("Main");
				mainMtage.setScene(scene);
				mainMtage.show();
			} catch (Exception e) {

			}
		});

		// ���Ź�ư �̺�Ʈ
		btnReserveOk.setOnAction(event -> {
			try {
				sd.reset();
				data.removeAll(data);
				MemberVo mbVo = null;
				MemberDAO mbDao = new MemberDAO();
				// ȸ�� ���� ����
				if (event.getSource().equals(btnReserveOk)) {
					mbVo = new MemberVo(txtMemberName.getText(), txtMemberBirth.getText(), txtMemberPhone1.getText(),
							txtMemberPhone2.getText(), txtMemberPhone3.getText(), password.getText(),
							passwordOk.getText(), lblMSeat.getText(), lblMDate.getText(), lblMMovie.getText());
					mbDao = new MemberDAO();
					mbDao.getMemberUpload(mbVo);
					if (mbDao != null) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("ȸ�� �Է�");
						alert.setHeaderText(txtMemberName.getText() + " ȸ�������� ���������� �߰��Ǿ����ϴ�..");

						alert.showAndWait();
						txtMemberName.clear();
						txtMemberBirth.clear();
						txtMemberPhone1.clear();
						txtMemberPhone2.clear();
						txtMemberPhone3.clear();
						password.clear();
						passwordOk.clear();
						StaticData.seat = 0;
						StaticData.seatNumber = null;
						
						FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/receipt.fxml"));
						Parent mainView = (Parent) loader.load();
						Scene scene = new Scene(mainView);
						Stage mainMtage = new Stage();
						Stage oldStage = (Stage) btnReserveCancle.getScene().getWindow();
						oldStage.close();
						mainMtage.setTitle("������");
						mainMtage.setScene(scene);
						mainMtage.show();

					}

				}
			} catch (Exception ie) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ȸ�� ���� �Է�");
				alert.setHeaderText("ȸ�� ������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}
		});
	}

}
