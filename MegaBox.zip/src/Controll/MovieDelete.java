package Controll;

import java.net.URL;
import java.util.ResourceBundle;

import Model.MovieVo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MovieDelete implements Initializable{
	@FXML private TextField txtMovieDelete;
	@FXML private Button btnMovieDeleteOk;
	ObservableList<MovieVo> data = FXCollections.observableArrayList();
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
		btnMovieDeleteOk.setOnAction(event -> {
			MovieDAO mDao = new MovieDAO();
			try {
			
				mDao.getMovieDelete(txtMovieDelete.getText());
				data.removeAll(data);
				
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Main.fxml"));
				Parent mainView = (Parent) loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				Stage oldStage = (Stage)btnMovieDeleteOk.getScene().getWindow();
				oldStage.close();
				mainMtage.setTitle("Member");
				mainMtage.setScene(scene);
				mainMtage.show();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}

}
