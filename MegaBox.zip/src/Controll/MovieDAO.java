package Controll;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.MovieVo;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import Controll.DBUtil;

public class MovieDAO {
	// ��ȭ���� db ���ε�
	public MovieVo getMovieUpload(MovieVo mvo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into movie");
		sql.append(" values (movie_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		MovieVo mVo = mvo;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, mVo.getTitle());
			pstmt.setString(2, mVo.getRate());
			pstmt.setString(3, mVo.getPremier());
			pstmt.setString(4, mVo.getDirector());
			pstmt.setString(5, mVo.getStaff());
			pstmt.setString(6, mVo.getScreenTime());
			pstmt.setString(7, mVo.getGenre());
			pstmt.setString(8, mVo.getType());
			pstmt.setString(9, mVo.getStory());
			pstmt.setString(10, mVo.getPoster());

			int i = pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("e = / " + e);
		} catch (Exception e) {
			System.out.println("e = / " + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {

			}
		}
		return mVo;
	}

	public MovieVo getMovieAll(String title) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * ");
		sql.append(" from movie where m_title=? order by m_number");

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		MovieVo mVo = new MovieVo();
		try {
			con = DBUtil.getConnection();
			ps = con.prepareStatement(sql.toString());
			ps.setString(1, title);
			rs = ps.executeQuery();
			while (rs.next()) {
				mVo = new MovieVo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10),
						rs.getString(11));

			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return mVo;
	}

	public ArrayList<MovieVo> getTitleSearch() {
		ArrayList<MovieVo> list = new ArrayList<MovieVo>();
		StringBuffer sql = new StringBuffer();
		sql.append("select m_title ");
		sql.append(" from movie order by m_number");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MovieVo mVo = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
			while (rs.next()) {
				mVo = new MovieVo();
				mVo.setTitle(rs.getString("m_title"));

				list.add(mVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return list;
	}

	public ArrayList<MovieVo> getMoviePoster() {
		ArrayList<MovieVo> list = new ArrayList<MovieVo>();
		StringBuffer sql = new StringBuffer();
		sql.append("select m_poster , m_title");
		sql.append(" from movie order by m_number");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MovieVo mVo = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				mVo = new MovieVo();
				mVo.setPoster(rs.getString("m_poster"));
				mVo.setTitle(rs.getString("m_title"));

				list.add(mVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return list;
	}

	public void getMovieDelete(String title) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from movie where m_title like ? ");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, "%" + title + "%");

			int i = pstmt.executeUpdate();
			System.out.println(i);
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ȭ ����");
				alert.setHeaderText("��ȭ ���� �Ϸ�");
				alert.setContentText("��ȭ ���� ���� !!");
				alert.showAndWait();

			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ȭ ����");
				alert.setHeaderText("��ȭ ���� ����");
				alert.setContentText("��ȭ ���� ���� !!");
				alert.showAndWait();

			}
		} catch (SQLException e) {
			System.out.println("e = [" + e + " ] ");
		} catch (Exception e) {
			System.out.println("e = [" + e + " ] ");
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {

			}
		}
	}

	// ��ȭdb ���� �˻�
	public MovieVo getMovieCheck(String title) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from movie where name like ");
		sql.append("? order by m_number desc");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MovieVo mVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, "%" + title + "%");

			rs = pstmt.executeQuery();

			if (rs.next()) {
				mVo = new MovieVo();
				mVo.setMovieNumber(rs.getString("movieNumber"));
				mVo.setTitle(rs.getString("title"));
				mVo.setRate(rs.getString("rate"));
				mVo.setPremier(rs.getString("Premier"));
				mVo.setDirector(rs.getString("director"));
				mVo.setStaff(rs.getString("staff"));
				mVo.setScreenTime(rs.getString("screenTime"));
				mVo.setGenre(rs.getString("genre"));
				mVo.setType(rs.getString("type"));
				mVo.setStory(rs.getString("story"));
				mVo.setPoster(rs.getString("poster"));

			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (Exception e) {

			}
		}
		return mVo;
	}

}
