package Controll;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.MemberVo;
import Model.MovieVo;
import javafx.fxml.Initializable;

public class MemberDAO {
	
	//ȸ�� ���� ���ε�
	public MemberVo getMemberUpload(MemberVo mbvo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into member");
		sql.append(" values (member_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		MemberVo mbVo = mbvo;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, mbVo.getMemberName());
			pstmt.setString(2, mbVo.getMemberBirth());
			pstmt.setString(3, mbVo.getPhone1());
			pstmt.setString(4, mbVo.getPhone2());
			pstmt.setString(5, mbVo.getPhone3());
			pstmt.setString(6, mbVo.getPassword());
			pstmt.setString(7, mbVo.getPasswordOk());
			pstmt.setString(8, mbVo.getSeat());
			pstmt.setString(9, mbVo.getDay());
			pstmt.setString(10, mbVo.getTitle());
			
			int i = pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("e = / " + e);
		} catch (Exception e) {
			System.out.println("e = / " + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {

			}
		}
		return mbVo;
	}

	public ArrayList<MemberVo> getMemberTotal() {
		ArrayList<MemberVo> list = new ArrayList<MemberVo>();
		StringBuffer sql = new StringBuffer();
		sql.append(
				"select * ");
		sql.append("from member order by mb_Number desc");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberVo mbVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				mbVo = new MemberVo();
				mbVo.setMemberNumber(rs.getString("mb_number"));
				mbVo.setMemberName(rs.getString("mb_name"));
				mbVo.setMemberBirth(rs.getString("mb_birth"));
				mbVo.setPhone1(rs.getString("mb_phone1"));
				mbVo.setPhone2(rs.getString("mb_phone2"));
				mbVo.setPhone3(rs.getString("mb_phone3"));
				mbVo.setPassword(rs.getString("mb_password"));
				mbVo.setPasswordOk(rs.getString("mb_passwordOk"));
				mbVo.setSeat(rs.getString("mb_seat"));
				mbVo.setDay(rs.getDate("mb_day") + "");
				mbVo.setTitle(rs.getString("m_title"));
				
				

				list.add(mbVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return list;
	}
	public ArrayList<MemberVo> getTitleSearch() {
		ArrayList<MemberVo> list = new ArrayList<MemberVo>();
		StringBuffer sql = new StringBuffer();
		sql.append("select m_title ");
		sql.append(" from member order by m_number");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberVo mbVo = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
			while (rs.next()) {
				mbVo = new MemberVo();
				mbVo.setTitle(rs.getString("m_title"));

				list.add(mbVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}
		}
		return list;
	}
}
