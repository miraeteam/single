package Model;

public class BranchVo {
	private String branchNumber;
	private String branchName;

	
	public BranchVo() {
		super();
	}

	public BranchVo(String branchName) {
		super();
		this.branchName = branchName;
	}

	public BranchVo(String branchNumber, String branchName) {
		super();
		this.branchNumber = branchNumber;
		this.branchName = branchName;
	}

	public String getBranchNumber() {
		return branchNumber;
	}

	public void setBranchNumber(String branchNumber) {
		this.branchNumber = branchNumber;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	
	
}
