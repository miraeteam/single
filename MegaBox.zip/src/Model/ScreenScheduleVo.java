package Model;

public class ScreenScheduleVo {
	private String screenNumner;
	private String screenTime;
	private String b_Screen;
	private String m_Screen;
	private String c_Screen;
	public ScreenScheduleVo() {
		super();
	}
	
	public ScreenScheduleVo(String screenTime, String b_Screen, String m_Screen, String c_Screen) {
		super();
		this.screenTime = screenTime;
		this.b_Screen = b_Screen;
		this.m_Screen = m_Screen;
		this.c_Screen = c_Screen;
	}

	public ScreenScheduleVo(String screenNumner, String screenTime, String b_Screen, String m_Screen, String c_Screen) {
		super();
		this.screenNumner = screenNumner;
		this.screenTime = screenTime;
		this.b_Screen = b_Screen;
		this.m_Screen = m_Screen;
		this.c_Screen = c_Screen;
	}

	public String getScreenNumner() {
		return screenNumner;
	}

	public void setScreenNumner(String screenNumner) {
		this.screenNumner = screenNumner;
	}

	public String getScreenTime() {
		return screenTime;
	}

	public void setScreenTime(String screenTime) {
		this.screenTime = screenTime;
	}

	public String getB_Screen() {
		return b_Screen;
	}

	public void setB_Screen(String b_Screen) {
		this.b_Screen = b_Screen;
	}

	public String getM_Screen() {
		return m_Screen;
	}

	public void setM_Screen(String m_Screen) {
		this.m_Screen = m_Screen;
	}

	public String getC_Screen() {
		return c_Screen;
	}

	public void setC_Screen(String c_Screen) {
		this.c_Screen = c_Screen;
	}
	
	
	
	
}
