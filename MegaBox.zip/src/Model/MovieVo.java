package Model;

public class MovieVo {
	private String movieNumber; //��ȭ ��ȣ
	private String title;	// ��ȭ ����
	private String rate;	//��ȭ ���ɵ��
	private String premier;	//��ȭ ������
	private String director; // ����
	private String staff; //�⿬��
	private String screenTime; //�󿵽ð�
	private String genre; //�帣
	private String type; //��ȭ Ÿ��
	private String story; //�̾߱�
	private String poster;  //��ȭ ������ 
	
	public MovieVo() {
		super();
	}

	public MovieVo(String title, String rate, String premier, String director, String staff,
			String screenTime, String genre, String type, String story, String poster) {
		super();
		this.title = title;
		this.rate = rate;
		this.premier = premier;
		this.director = director;
		this.staff = staff;
		this.screenTime = screenTime;
		this.genre = genre;
		this.type = type;
		this.story = story;
		this.poster = poster;
	}

	public MovieVo(String poster) {
		super();
		this.poster = poster;
	}

	public MovieVo(String movieNumber, String title, String rate, String premier, String director,
			String staff, String screenTime, String genre, String type, String story, String poster) {
		super();
		this.movieNumber = movieNumber;
		this.title = title;
		this.rate = rate;
		this.premier = premier;
		this.director = director;
		this.staff = staff;
		this.screenTime = screenTime;
		this.genre = genre;
		this.type = type;
		this.story = story;
		this.poster = poster;
	}

	public String getMovieNumber() {
		return movieNumber;
	}

	public void setMovieNumber(String movieNumber) {
		this.movieNumber = movieNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getPremier() {
		return premier;
	}

	public void setPremier(String premier) {
		this.premier = premier;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getStaff() {
		return staff;
	}

	public void setStaff(String staff) {
		this.staff = staff;
	}

	public String getScreenTime() {
		return screenTime;
	}

	public void setScreenTime(String screenTime) {
		this.screenTime = screenTime;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStory() {
		return story;
	}

	public void setStory(String story) {
		this.story = story;
	}

	public String getPoster() {
		return poster;
	}

	public void setPoster(String poster) {
		this.poster = poster;
	}


	
	
}
