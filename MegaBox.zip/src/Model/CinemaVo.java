package Model;

public class CinemaVo {
	private String cinemaNumber;
	private String cinema;
	private String b_cinema;
	public CinemaVo() {
		super();
	}
	
	public CinemaVo(String cinema) {
		super();
		this.cinema = cinema;
	}

	public CinemaVo(String cinema, String b_cinema) {
		super();
		this.cinema = cinema;
		this.b_cinema = b_cinema;
	}

	public CinemaVo(String cinemaNumber, String cinema, String b_cinema) {
		super();
		this.cinemaNumber = cinemaNumber;
		this.cinema = cinema;
		this.b_cinema = b_cinema;
	}

	public String getCinemaNumber() {
		return cinemaNumber;
	}

	public void setCinemaNumber(String cinemaNumber) {
		this.cinemaNumber = cinemaNumber;
	}

	public String getCinema() {
		return cinema;
	}

	public void setCinema(String cinema) {
		this.cinema = cinema;
	}

	public String getB_cinema() {
		return b_cinema;
	}

	public void setB_cinema(String b_cinema) {
		this.b_cinema = b_cinema;
	}
	
	
	
	
}
