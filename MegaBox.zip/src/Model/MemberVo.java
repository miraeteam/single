package Model;

public class MemberVo {
	private String memberNumber;
	private String memberName;
	private String memberBirth;
	private String phone1;
	private String phone2;
	private String phone3;
	private String password;
	private String passwordOk;
	private String seat;
	private String day;
	private String title;
	
	
	public MemberVo() {
		super();
	}


	public MemberVo(String memberName, String memberBirth, String phone1, String phone2, String phone3, String password,
			String passwordOk, String seat, String day, String title) {
		super();
		this.memberName = memberName;
		this.memberBirth = memberBirth;
		this.phone1 = phone1;
		this.phone2 = phone2;
		this.phone3 = phone3;
		this.password = password;
		this.passwordOk = passwordOk;
		this.seat = seat;
		this.day = day;
		this.title = title;
	}


	

	public MemberVo(String memberNumber, String memberName, String memberBirth, String phone1, String phone2,
			String phone3, String password, String passwordOk, String seat, String day, String title) {
		super();
		this.memberNumber = memberNumber;
		this.memberName = memberName;
		this.memberBirth = memberBirth;
		this.phone1 = phone1;
		this.phone2 = phone2;
		this.phone3 = phone3;
		this.password = password;
		this.passwordOk = passwordOk;
		this.seat = seat;
		this.day = day;
		this.title = title;
	}


	public String getMemberNumber() {
		return memberNumber;
	}


	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}


	public String getMemberName() {
		return memberName;
	}


	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}


	public String getMemberBirth() {
		return memberBirth;
	}


	public void setMemberBirth(String memberBirth) {
		this.memberBirth = memberBirth;
	}


	public String getPhone1() {
		return phone1;
	}


	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}


	public String getPhone2() {
		return phone2;
	}


	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}


	public String getPhone3() {
		return phone3;
	}


	public void setPhone3(String phone3) {
		this.phone3 = phone3;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getPasswordOk() {
		return passwordOk;
	}


	public void setPasswordOk(String passwordOk) {
		this.passwordOk = passwordOk;
	}


	public String getSeat() {
		return seat;
	}


	public void setSeat(String seat) {
		this.seat = seat;
	}


	public String getDay() {
		return day;
	}


	public void setDay(String day) {
		this.day = day;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}
	
	
	

	
	
}
